/* global QUnit */

sap.ui.require(["com/yokogawa/zhfi0002/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
