sap.ui.define([
	"comyokogawa/zhfi0002/test/unit/controller/App.controller"
], function () {
	"use strict";
});
